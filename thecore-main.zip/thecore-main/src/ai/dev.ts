import { config } from 'dotenv';
config();

import '@/ai/flows/generate-dynamic-background.ts';
import '@/ai/flows/generate-vocabulary-quiz.ts';
